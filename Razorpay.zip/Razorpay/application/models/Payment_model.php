<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class payment_model extends CI_Model {
	

	public function __construct(){
		parent::__construct();
	}

	public function fetchCustomerData($customerid){
		$this->db->select('*');
		$this->db->where('customer_id', $customerid);
		$query = $this->db->get('customer');
		return $query->row();		
	}
}	