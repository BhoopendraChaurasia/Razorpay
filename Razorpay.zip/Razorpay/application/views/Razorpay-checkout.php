<p>Do not press any button. Payment is processing...</p>
<a href="<?=base_url().?>">Back</a>
<button id="rzp-button1" style="display none;">Pay</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
    "key": "<?=$key_id?>", // Enter the Key ID generated from the Dashboard
    "amount": "<?=$order['amount']*100?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Acme Corp",
    "description": "Test Transaction",
    "image": "https://example.com/your_logo",
    "order_id": "<?=$order['id']?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
    "callback_url": "<?=base_url('payment/paymentStatus')?>",
    "prefill": {
        "name": "<?=$customerdata->customer_name?>",
        "email": "<?=$customerdata->customer_email?>",
        "contact": "<?=$customerdata->customer_mobileno?>"
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
document.getElementById('rzp-button1').click();
</script>
