<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'views/razorpay/Razorpay.php';

use Razorpay\Api\Api;
class Payment extends CI_Controller {
	

	public function __construct(){
		parent::__construct();
		$this->load->view('payment_model');
	}

	public function index(){
		$customerid = 1;
		$this->session->set_userdata('customer_id', $customerid);
		$customerdata = $this->payment_model->fetchCustomerData($customerid);
		$this->load->view('payment-view', ['customerdata' => $customerdata]);
	}
	// Order Creation
	public function checkout(){
		$key_id         = "rzp_test_Ba15PeBjXwiqIR";
        $key_secret     = "E242hlIbkarnfIFnCQTN52Z6";
		$price = $this->input->post('price');

		$api = new Api($key_id, $secret);

		$order = $api->order->create([
			'receipt' => 'order_rcptid_11', 
			'amount' => $price, 
			'currency' => 'INR'
		]);
		// Customer detail

		$customerid = $this->session->userdata('customer_id');
		$customerdata = $this->payment_model->fetchCustomerData($customerid);
		$this->load->view('razorpay-checkout', ['customerdata' => $customerdata, 'order' => $order, 'key_id' => $key_id, 'secret' => $key_secret]);
	}

	public function paymentStatus(){
		// response of payment status  
		print_r($_POST);
	}

}